package Connection;

public class LoomContext {
	String item;

	LoomContext(String s) {item=s;}
}
